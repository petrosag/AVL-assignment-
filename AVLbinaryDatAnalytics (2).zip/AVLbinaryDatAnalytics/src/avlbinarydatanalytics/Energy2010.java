package avlbinarydatanalytics;





/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author petro
 */
public enum Energy2010 {
    
    
    Year ;
    String County;
    String Municipality;
    int DEC_ID;
    String Facility_Name;
    String Location;
    int SIC_Code;
    int VOC;
    int NOx;
    int CO;
    int CO2;
    int Particulates;
    int PM10;
    int PM25;
    int HAPS;
    int SO2;

    public int getValue() {
       return CO2;
     }
   
    
}

/*

Year	County	Municipality	DEC_ID	Facility_Name	SIC_Code	VOC	NOx	CO 	CO2	Particulates	PM10 	PM2.5 	HAPS 	SO2	Location

 */
