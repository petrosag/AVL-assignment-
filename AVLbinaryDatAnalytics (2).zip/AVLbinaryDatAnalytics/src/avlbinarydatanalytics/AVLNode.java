/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avlbinarydatanalytics;

/**
 *
 * @author petro
 */
public class AVLNode {

    int data, height;
    AVLNode left, right;
    Energy2010 energy2010;

    public AVLNode(int data, AVLNode left, AVLNode right, Energy2010 energy2010) {
        this.data = data;
        this.left = left;
        this.right = right;
        this.energy2010 = energy2010;
    }

    AVLNode(int d) {
        data = d;
        height = 0;
        left = null;
        right = null;

    }

    AVLNode() {
        left = null;
        right = null;
        data = 0;
        height = 0;

    }

}
