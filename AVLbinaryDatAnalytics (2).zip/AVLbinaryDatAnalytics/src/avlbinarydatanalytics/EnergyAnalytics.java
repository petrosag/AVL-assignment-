/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avlbinarydatanalytics;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author petro
 */
public class EnergyAnalytics {

    public static void main(String[] args) throws FileNotFoundException, IOException {

        AVLTree tr = new AVLTree();
        FileInputStream fstream = new FileInputStream("C:\\Users\\petro\\Documents\\NetBeansProjects\\AVLbinaryDatAnalytics\\src\\avlbinarydatanalytics\\Emissions2010.csv");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(fstream))) {
            String line;
            int counter;
            try {
                while ((line = br.readLine()) != null) {
                    if (Character.isDigit(line.charAt(0))) {
                        StringBuilder builder = new StringBuilder(line);
                        boolean inQuotes = false;

                        
                        for (int currentIndex = 0; currentIndex < builder.length(); currentIndex++) {
                            char currentChar = builder.charAt(currentIndex);
                            if (currentChar == '\"') {
                                inQuotes = !inQuotes; 
                            }
                            if (currentChar == ',' && inQuotes) {
                                builder.setCharAt(currentIndex, ';'); 
                            }
                        }
                        List<String> result = Arrays.asList(builder.toString()
                                .replace(";", "")
                                .replace(" ", "")
                                .replace("\"", "")
                                .split(","));

                        tr.insert(Integer.parseInt(result.get(Energy2010.Year.getValue())));
                       
                        //String numberAsString = new Integer(number).toString();

                    }
                }
            } catch (IOException ex) {
                Logger.getLogger(EnergyAnalytics.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        System.out.println(tr.countNodes()); 
        tr.inorder();
        System.out.println();
        tr.postorder();
    }
}

/*
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) throws FileNotFoundException, IOException {
        String readCSV = "C:\\Users\\petro\\Documents\\NetBeansProjects\\AVLbinaryDatAnalytics\\src\\avlbinarydatanalytics\\Emissions2010.csv";
        String line = " ";
        String splitCSV = ",";
        BufferedReader br = new BufferedReader(new FileReader(readCSV));
        while ((line = br.readLine()) != null) {

            String[] allline = line.split(splitCSV);
            String Year = allline[0];
            String County = allline[1];
            String Municipality = allline[2];
            int DEC_ID = 0;

            String Facility_Name = allline[4];
            String Location = allline[5];
            int SIC_Code = 0;
            int VOC = 0;
            int NOx = 0;
            int CO = 0;
            int CO2 = 0;
            int Particulates = 0;
            int PM10 = 0;
            int PM25 = 0;
            int HAPS = 0;
            int SO2 = 0;

            SIC_Code = Math.round(Float.parseFloat(allline[6]));
            VOC = Math.round(Float.parseFloat(allline[7]));
            NOx = Math.round(Float.parseFloat(allline[8]));
            CO = Math.round(Float.parseFloat(allline[9]));
            CO2 = Math.round(Float.parseFloat(allline[10]));
            Particulates = Math.round(Float.parseFloat(allline[11]));
            PM10 = Math.round(Float.parseFloat(allline[12]));
            PM25 = Math.round(Float.parseFloat(allline[13]));
            HAPS = Math.round(Float.parseFloat(allline[14]));
            SO2 = Math.round(Float.parseFloat(allline[15]));

          

            /* String[] County = line.split(splitCSV);
            String[] Facility_Name = line.split(splitCSV);
            String[] CO = line.split(splitCSV);
            String[] Location = line.split(splitCSV);
            
            Energy2010 bill = new Energy2010(Year, County, Facility_Name, Location, CO);
            data.add(bill);

            System.out.println(" " + Arrays.toString(Year) + " [" + Arrays.toString(County) + "  [" + Arrays.toString(Facility_Name) + "  [" + Arrays.toString(CO));
        }*/

 /*String csvFile = ;
        List<Energy2010> data = new ArrayList();
        data = read.readEnergyFromCSV("C:\\Users\\petro\\Documents\\NetBeansProjects\\AVLbinaryDatAnalytics\\src\\avlbinarydatanalytics\\Emissions2010.csv");
        for (Energy2010 items: data ){
            System.out.println("Year [" + items.Year + "County [" + items.County + " Facility_Name [" + items.Facility_Name + " CO (tons) ["+ items.CO);
            AVLTree avl = new AVLTree();
            avl.insert(items.CO);*/

