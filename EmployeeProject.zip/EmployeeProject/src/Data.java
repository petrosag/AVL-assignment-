
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author petro
 */
public class Data {

    public static void main(String[] args) {
        // TODO code application logic here
        List<EmployeeProject> lst = new ArrayList();
        ReadData rf = new ReadData();
        lst = rf.readCSV("C:\\Users\\petro\\Documents\\NetBeansProjects\\EmployeeProject\\src\\employeeSalary");
        Employee bst = new Employee();

        for (int i = 0; i < lst.size(); i++) {
            if (i == 0) {
            } else {
                int diff = Math.abs(lst.get(i - 1).getSalary() - lst.get(i).getSalary());
                System.out.println("Digits: " + lst.get(i).getSalary() + " Previous: " + lst.get(i - 1).getSalary() + " Difference: " + diff);
                bst.insert(lst.get(i));
            }
        }


        /*  Display tree  */
        System.out.print("\nPost order : ");
        bst.postorder();
        System.out.print("\nPre order : ");
        bst.preorder();
        System.out.print("\nIn order : ");
        bst.inorder();
    }

}
