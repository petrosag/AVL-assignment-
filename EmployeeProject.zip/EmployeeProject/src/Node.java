/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author petro
 */
public class Node {

    EmployeeProject data;

    public Node(EmployeeProject data) {
        left = null;
        right = null;
        data = data;
    }

    Node left, right;

}
