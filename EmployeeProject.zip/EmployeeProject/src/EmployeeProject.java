
import java.io.BufferedReader;
import java.io.FileReader;
import static javax.management.Query.value;
import static javax.management.Query.value;
import static javax.management.Query.value;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author petro
 */
/**
 */
public class EmployeeProject {

    public EmployeeProject() {
    }
    int Salary;
    String Name;
    int SalDifference = -3000;

    public EmployeeProject(String Name, int Salary) {
        this.Salary = Salary;
        this.Name = Name;
    }

    public int getSalary() {
        return Salary;
    }

    public void setSalary(int Salary) {
        this.Salary = Salary;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getSalDifference() {
        return SalDifference;
    }

    public void setSalDifference(int SalDifference) {
        this.SalDifference = SalDifference;
    }

    //int setSalDifference = data - value;
}
/*
    public void display() {
        if (SalDifference <= -3000) {
            System.out.println("Input another salary");
        } else {
            System.out.print("Name " + Name);
            System.out.println(" Salary " + Salary);
        }

    }*/


