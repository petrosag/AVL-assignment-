
import java.util.Scanner;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author petro
 */
public class LinkedList {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        /* Creating object of BST */
        Employee bst = new Employee();
        
        System.out.println("Linked List Binary Search Tree Test\n");
        char ch;
        /*  Access  */
        do {
            System.out.println("Enter integer element to insert");
            EmployeeProject data = new EmployeeProject();
            data.setName(scan.next());
            data.setSalary(scan.nextInt());
            bst.insert(data);

           /*  Display tranversally */
            System.out.print("\nPost order : ");
            bst.postorder();
            System.out.print("\nPre order : ");
            bst.preorder();
            System.out.print("\nIn order : ");
            bst.inorder();

            System.out.println("\nDo you want to continue (Type y or n) \n");
            ch = scan.next().charAt(0);
        } while (ch == 'Y' || ch == 'y');
    }

    
    
}
