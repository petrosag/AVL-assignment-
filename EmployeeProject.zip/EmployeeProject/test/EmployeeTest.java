/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author petro
 */
public class EmployeeTest {
    
    public EmployeeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of insert method, of class Employee.
     */
    @Test
    public void testInsert() {
        System.out.println("insert");
        EmployeeProject data = null;
        Employee instance = new Employee();
        instance.insert(data);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of inorder method, of class Employee.
     */
    @Test
    public void testInorder() {
        System.out.println("inorder");
        Employee instance = new Employee();
        instance.inorder();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of preorder method, of class Employee.
     */
    @Test
    public void testPreorder() {
        System.out.println("preorder");
        Employee instance = new Employee();
        instance.preorder();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of postorder method, of class Employee.
     */
    @Test
    public void testPostorder() {
        System.out.println("postorder");
        Employee instance = new Employee();
        instance.postorder();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of delete method, of class Employee.
     */
    @Test
    public void testDelete() {
        System.out.println("delete");
        int data = 0;
        Employee instance = new Employee();
        Employee expResult = null;
        Employee result = instance.delete(data);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of search method, of class Employee.
     */
    @Test
    public void testSearch() {
        System.out.println("search");
        Employee root = null;
        int data = 0;
        Employee instance = new Employee();
        Employee expResult = null;
        Employee result = instance.search(root, data);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Employee.
     */
    @Test
    public void testMain() throws Exception {
        System.out.println("main");
        String[] args = null;
        Employee instance = new Employee();
        instance.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
